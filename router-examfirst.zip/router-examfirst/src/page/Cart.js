import React from 'react'

const Cart = () => {
  return (
    <div>
        장바구니 화면
      
    </div>
  )
}

export default Cart
