import React from 'react'

const PrivateRoute = () => {
  return (
    <div>
        private 페이지
      
    </div>
  )
}

export default PrivateRoute
