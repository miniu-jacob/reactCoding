import React from 'react'

const Products = () => {
  return (
    <div>
        상품 페이지 화면
      
    </div>
  )
}

export default Products
