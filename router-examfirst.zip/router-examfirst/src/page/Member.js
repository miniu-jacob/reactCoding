import React from 'react'

const Member = () => {
  return (
    <div>
        로그인한 유저가 볼 수 있는 페이지
      
    </div>
  )
}

export default Member
