import React from 'react'

const About = () => {
  return (
    <div>
        About 페이지 입니다.        
      
    </div>
  )
}

export default About

