import React from 'react'

const Login = () => {
  return (
    <div>
      <h2>로그인 페이지. 로그인하세요.</h2>
      
    </div>
  )
}

export default Login
