import React from 'react'

const UserPage = () => {
  return (
    <div>
      <h2>유저 페이지, 로그인한 유저만 볼 수 있음.</h2>
      
    </div>
  )
}

export default UserPage
